module.exports = 'Desarrollar operaciones en máquinas de confección'
